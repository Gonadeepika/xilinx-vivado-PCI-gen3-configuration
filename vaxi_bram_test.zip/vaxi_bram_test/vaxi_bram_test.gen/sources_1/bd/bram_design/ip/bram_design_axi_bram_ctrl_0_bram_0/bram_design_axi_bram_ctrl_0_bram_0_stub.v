// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (lin64) Build 6140274 Wed May 21 22:58:25 MDT 2025
// Date        : Fri Jun 19 15:44:32 2026
// Host        : RISCV-NSM-Veloce running 64-bit Red Hat Enterprise Linux release 8.10 (Ootpa)
// Command     : write_verilog -force -mode synth_stub
//               /home/HCL5/saketh/VIVADO_PROJECTS/vaxi_bram_test/vaxi_bram_test.gen/sources_1/bd/bram_design/ip/bram_design_axi_bram_ctrl_0_bram_0/bram_design_axi_bram_ctrl_0_bram_0_stub.v
// Design      : bram_design_axi_bram_ctrl_0_bram_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xcvp1902-vsva6865-2MP-e-S
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "bram_design_axi_bram_ctrl_0_bram_0,emb_mem_gen_v1_0_11,{}" *) (* CORE_GENERATION_INFO = "bram_design_axi_bram_ctrl_0_bram_0,emb_mem_gen_v1_0_11,{x_ipProduct=Vivado 2025.1,x_ipVendor=xilinx.com,x_ipLibrary=ip,x_ipName=emb_mem_gen,x_ipVersion=1.0,x_ipCoreRevision=11,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,C_XPM_SELECT=0,C_MEMORY_TYPE=2,C_MEMORY_SIZE=65536,C_MEMORY_PRIMITIVE=2,C_CLOCKING_MODE=0,C_ECC_MODE=0,C_ECC_TYPE=NONE,C_ECC_BIT_RANGE=7_0,C_MEMORY_INIT_FILE=none,C_WAKEUP_TIME=0,C_AUTO_SLEEP_TIME=0,C_MESSAGE_CONTROL=0,C_VERSION=0,C_WRITE_DATA_WIDTH_A=32,C_READ_DATA_WIDTH_A=32,C_BYTE_WRITE_WIDTH_A=8,C_ADDR_WIDTH_A=13,C_READ_RESET_VALUE_A=0,C_MEMORY_INIT_PARAM=0,C_READ_LATENCY_A=1,C_WRITE_MODE_A=0,C_RST_MODE_A=SYNC,C_WRITE_DATA_WIDTH_B=32,C_READ_DATA_WIDTH_B=32,C_BYTE_WRITE_WIDTH_B=8,C_ADDR_WIDTH_B=13,C_READ_RESET_VALUE_B=0,C_READ_LATENCY_B=1,C_WRITE_MODE_B=0,C_RST_MODE_B=SYNC,C_ENABLE_32BIT_ADDRESS=1,C_MEMORY_OPTIMIZATION=1,C_USE_EMBEDDED_CONSTRAINT=0,C_CASCADE_HEIGHT=0,C_ALGORITHM=auto,C_SIM_ASSERT_CHK=0,C_WRITE_PROTECT=1,C_IGNORE_INIT_SYNTH=0,C_ENABLE_INIT_FILE_ECC=0,C_Component_Name=bram_design_axi_bram_ctrl_0_bram_0}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* X_CORE_INFO = "emb_mem_gen_v1_0_11,Vivado 2025.1" *) 
module bram_design_axi_bram_ctrl_0_bram_0(clka, rsta, ena, regcea, wea, addra, dina, douta, clkb, 
  rstb, enb, regceb, web, addrb, dinb, doutb)
/* synthesis syn_black_box black_box_pad_pin="rsta,ena,regcea,wea[3:0],addra[12:0],dina[31:0],douta[31:0],clkb,rstb,enb,regceb,web[3:0],addrb[12:0],dinb[31:0],doutb[31:0]" */
/* synthesis syn_force_seq_prim="clka" */;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK, xilinx.com:signal:clock:1.0 clka CLK" *) (* X_INTERFACE_MODE = "slave clka" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clka, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input clka /* synthesis syn_isclock = 1 */;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA RST" *) input rsta;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  input regcea;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [3:0]wea;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [12:0]addra;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [31:0]dina;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB CLK, xilinx.com:signal:clock:1.0 clkb CLK" *) (* X_INTERFACE_MODE = "slave clkb" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clkb, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input clkb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB RST" *) input rstb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB EN" *) input enb;
  input regceb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB WE" *) input [3:0]web;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB ADDR" *) input [12:0]addrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB DIN" *) input [31:0]dinb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 BRAM_PORTB DOUT" *) output [31:0]doutb;
endmodule
