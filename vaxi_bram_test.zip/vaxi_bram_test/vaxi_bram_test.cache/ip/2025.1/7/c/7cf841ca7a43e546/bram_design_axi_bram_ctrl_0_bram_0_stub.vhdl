-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (lin64) Build 6140274 Wed May 21 22:58:25 MDT 2025
-- Date        : Fri Jun 19 15:44:22 2026
-- Host        : RISCV-NSM-Veloce running 64-bit Red Hat Enterprise Linux release 8.10 (Ootpa)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ bram_design_axi_bram_ctrl_0_bram_0_stub.vhdl
-- Design      : bram_design_axi_bram_ctrl_0_bram_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xcvp1902-vsva6865-2MP-e-S
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clka : in STD_LOGIC;
    rsta : in STD_LOGIC;
    ena : in STD_LOGIC;
    regcea : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 3 downto 0 );
    addra : in STD_LOGIC_VECTOR ( 12 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 31 downto 0 );
    douta : out STD_LOGIC_VECTOR ( 31 downto 0 );
    clkb : in STD_LOGIC;
    rstb : in STD_LOGIC;
    enb : in STD_LOGIC;
    regceb : in STD_LOGIC;
    web : in STD_LOGIC_VECTOR ( 3 downto 0 );
    addrb : in STD_LOGIC_VECTOR ( 12 downto 0 );
    dinb : in STD_LOGIC_VECTOR ( 31 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "bram_design_axi_bram_ctrl_0_bram_0,emb_mem_gen_v1_0_11,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "bram_design_axi_bram_ctrl_0_bram_0,emb_mem_gen_v1_0_11,{x_ipProduct=Vivado 2025.1,x_ipVendor=xilinx.com,x_ipLibrary=ip,x_ipName=emb_mem_gen,x_ipVersion=1.0,x_ipCoreRevision=11,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,C_XPM_SELECT=0,C_MEMORY_TYPE=2,C_MEMORY_SIZE=65536,C_MEMORY_PRIMITIVE=2,C_CLOCKING_MODE=0,C_ECC_MODE=0,C_ECC_TYPE=NONE,C_ECC_BIT_RANGE=7_0,C_MEMORY_INIT_FILE=none,C_WAKEUP_TIME=0,C_AUTO_SLEEP_TIME=0,C_MESSAGE_CONTROL=0,C_VERSION=0,C_WRITE_DATA_WIDTH_A=32,C_READ_DATA_WIDTH_A=32,C_BYTE_WRITE_WIDTH_A=8,C_ADDR_WIDTH_A=13,C_READ_RESET_VALUE_A=0,C_MEMORY_INIT_PARAM=0,C_READ_LATENCY_A=1,C_WRITE_MODE_A=0,C_RST_MODE_A=SYNC,C_WRITE_DATA_WIDTH_B=32,C_READ_DATA_WIDTH_B=32,C_BYTE_WRITE_WIDTH_B=8,C_ADDR_WIDTH_B=13,C_READ_RESET_VALUE_B=0,C_READ_LATENCY_B=1,C_WRITE_MODE_B=0,C_RST_MODE_B=SYNC,C_ENABLE_32BIT_ADDRESS=1,C_MEMORY_OPTIMIZATION=1,C_USE_EMBEDDED_CONSTRAINT=0,C_CASCADE_HEIGHT=0,C_ALGORITHM=auto,C_SIM_ASSERT_CHK=0,C_WRITE_PROTECT=1,C_IGNORE_INIT_SYNTH=0,C_ENABLE_INIT_FILE_ECC=0,C_Component_Name=bram_design_axi_bram_ctrl_0_bram_0}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "clka,rsta,ena,regcea,wea[3:0],addra[12:0],dina[31:0],douta[31:0],clkb,rstb,enb,regceb,web[3:0],addrb[12:0],dinb[31:0],doutb[31:0]";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clka : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK, xilinx.com:signal:clock:1.0 clka CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clka : signal is "slave clka";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clka : signal is "XIL_INTERFACENAME clka, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of rsta : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA RST";
  attribute X_INTERFACE_INFO of ena : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA EN";
  attribute X_INTERFACE_INFO of wea : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA WE";
  attribute X_INTERFACE_INFO of addra : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR";
  attribute X_INTERFACE_INFO of dina : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN";
  attribute X_INTERFACE_INFO of douta : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT";
  attribute X_INTERFACE_INFO of clkb : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB CLK, xilinx.com:signal:clock:1.0 clkb CLK";
  attribute X_INTERFACE_MODE of clkb : signal is "slave clkb";
  attribute X_INTERFACE_PARAMETER of clkb : signal is "XIL_INTERFACENAME clkb, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of rstb : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB RST";
  attribute X_INTERFACE_INFO of enb : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB EN";
  attribute X_INTERFACE_INFO of web : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB WE";
  attribute X_INTERFACE_INFO of addrb : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB ADDR";
  attribute X_INTERFACE_INFO of dinb : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB DIN";
  attribute X_INTERFACE_INFO of doutb : signal is "xilinx.com:interface:bram:1.0 BRAM_PORTB DOUT";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "emb_mem_gen_v1_0_11,Vivado 2025.1";
begin
end;
