vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xilinx_vip
vlib modelsim_lib/msim/xpm
vlib modelsim_lib/msim/axi_bram_ctrl_v4_1_13
vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/emb_mem_gen_v1_0_11

vmap xilinx_vip modelsim_lib/msim/xilinx_vip
vmap xpm modelsim_lib/msim/xpm
vmap axi_bram_ctrl_v4_1_13 modelsim_lib/msim/axi_bram_ctrl_v4_1_13
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap emb_mem_gen_v1_0_11 modelsim_lib/msim/emb_mem_gen_v1_0_11

vlog -work xilinx_vip -64 -incr -mfcu  -sv -L emb_mem_gen_v1_0_11 "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm -64 -incr -mfcu  -sv -L emb_mem_gen_v1_0_11 "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -64 -93  \
"/opt/Vivado_Install/2025_1/2025.1/data/ip/xpm/xpm_VCOMP.vhd" \

vcom -work axi_bram_ctrl_v4_1_13 -64 -93  \
"../../../../vaxi_bram_test.gen/sources_1/bd/bram_design/ipshared/2f03/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/bram_design/ip/bram_design_axi_bram_ctrl_0_0/sim/bram_design_axi_bram_ctrl_0_0.vhd" \

vlog -work emb_mem_gen_v1_0_11 -64 -incr -mfcu  -sv -L emb_mem_gen_v1_0_11 "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" \
"../../../../vaxi_bram_test.gen/sources_1/bd/bram_design/ipshared/0f67/hdl/emb_mem_gen_v1_0_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L emb_mem_gen_v1_0_11 "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" \
"../../../bd/bram_design/ip/bram_design_axi_bram_ctrl_0_bram_0/sim/bram_design_axi_bram_ctrl_0_bram_0.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" \
"../../../bd/bram_design/sim/bram_design.v" \

vlog -work xil_defaultlib \
"glbl.v"

