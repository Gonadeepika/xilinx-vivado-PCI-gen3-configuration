transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

asim +access +r +m+bram_design  -L xil_defaultlib -L xilinx_vip -L xpm -L axi_bram_ctrl_v4_1_13 -L emb_mem_gen_v1_0_11 -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.bram_design xil_defaultlib.glbl

do {bram_design.udo}

run 1000ns

endsim

quit -force
