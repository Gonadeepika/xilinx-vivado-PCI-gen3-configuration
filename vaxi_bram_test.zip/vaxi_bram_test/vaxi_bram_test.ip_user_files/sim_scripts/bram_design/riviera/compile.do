transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib riviera/xilinx_vip
vlib riviera/xpm
vlib riviera/axi_bram_ctrl_v4_1_13
vlib riviera/xil_defaultlib
vlib riviera/emb_mem_gen_v1_0_11

vmap xilinx_vip riviera/xilinx_vip
vmap xpm riviera/xpm
vmap axi_bram_ctrl_v4_1_13 riviera/axi_bram_ctrl_v4_1_13
vmap xil_defaultlib riviera/xil_defaultlib
vmap emb_mem_gen_v1_0_11 riviera/emb_mem_gen_v1_0_11

vlog -work xilinx_vip  -incr "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_bram_ctrl_v4_1_13 -l xil_defaultlib -l emb_mem_gen_v1_0_11 \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm  -incr "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_bram_ctrl_v4_1_13 -l xil_defaultlib -l emb_mem_gen_v1_0_11 \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/opt/Vivado_Install/2025_1/2025.1/Vivado/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -93  -incr \
"/opt/Vivado_Install/2025_1/2025.1/data/ip/xpm/xpm_VCOMP.vhd" \

vcom -work axi_bram_ctrl_v4_1_13 -93  -incr \
"../../../../vaxi_bram_test.gen/sources_1/bd/bram_design/ipshared/2f03/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -93  -incr \
"../../../bd/bram_design/ip/bram_design_axi_bram_ctrl_0_0/sim/bram_design_axi_bram_ctrl_0_0.vhd" \

vlog -work emb_mem_gen_v1_0_11  -incr "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_bram_ctrl_v4_1_13 -l xil_defaultlib -l emb_mem_gen_v1_0_11 \
"../../../../vaxi_bram_test.gen/sources_1/bd/bram_design/ipshared/0f67/hdl/emb_mem_gen_v1_0_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_bram_ctrl_v4_1_13 -l xil_defaultlib -l emb_mem_gen_v1_0_11 \
"../../../bd/bram_design/ip/bram_design_axi_bram_ctrl_0_bram_0/sim/bram_design_axi_bram_ctrl_0_bram_0.sv" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../../../../../../opt/Vivado_Install/2025_1/2025.1/data/rsb/busdef" "+incdir+/opt/Vivado_Install/2025_1/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_bram_ctrl_v4_1_13 -l xil_defaultlib -l emb_mem_gen_v1_0_11 \
"../../../bd/bram_design/sim/bram_design.v" \

vlog -work xil_defaultlib \
"glbl.v"

